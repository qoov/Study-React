## Welcome
This is the source code for a book about React, [React in Action by Mark Thomas](https://ifelse.io/book). If you'd like to suggest a change or find somehting missing, make sure to open an issue here or at the [errata](https://github.com/react-in-action/errata) repo.
